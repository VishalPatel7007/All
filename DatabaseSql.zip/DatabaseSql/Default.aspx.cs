﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;

    void mycon()
    {
        con = new SqlConnection(@"Data Sourcxe=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\registration.mdf;Integrated Security=True");
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string path = "";
        mycon();

        cmd = new SqlCommand("Insert into Registration values(@nm,@em,@ps,@mo,@gen,@dod,@img,@rd)", con);
        cmd.Parameters.AddWithValue("@nm",Textname);
        cmd.Parameters.AddWithValue("@em", Textemail);
        cmd.Parameters.AddWithValue("@ps", Textpassword);
        cmd.Parameters.AddWithValue("@mo", Textmobile);
        cmd.Parameters.AddWithValue("@gen", RadioButtonList1.Text);
        cmd.Parameters.AddWithValue("@dob", DropDownList1.Text+"/"+DropDownList2.Text+"/"+DropDownList3.Text);

        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/img/" + FileUpload1.FileName));
            path = "~/img/" + FileUpload1.FileName;

        }

        cmd.Parameters.AddWithValue("@img", path);
        cmd.Parameters.AddWithValue("@rd", System.DateTime.Now.ToString());
        cmd.ExecuteNonQuery();
        con.Close();

        Response.Write("<script>alert('SuccessFull Register With Us.')</script>");
        Textname.Text = "";
        Textemail.Text = "";
        Textpassword.Text = "";
        Textmobile.Text = "";
        RadioButtonList1.SelectedIndex = -1;
        DropDownList1.SelectedIndex = 0;
        DropDownList2.SelectedIndex = 0;
        DropDownList3.SelectedIndex = 0;


    }
}